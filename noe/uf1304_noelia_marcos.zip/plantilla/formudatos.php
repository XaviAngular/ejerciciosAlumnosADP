<?php
if($_SERVER['REQUEST_METHOD'] ==='POST'){
	echo "$_POST['author']";
	echo "<br>"
	echo "$_POST['email']";
	echo "<br>"
	echo "$_POST['phone']";
	echo "<br>"
	echo "$_POST['text']";
} else {
	echo"Datos no enviados desde formulario";
}
?>