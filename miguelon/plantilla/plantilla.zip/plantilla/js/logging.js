$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+917180+'&oi='+72+'&ot=1&&url='+window.location, function(json){})    

});